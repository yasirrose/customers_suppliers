export const initialAbility = [{
    action: ['test'],
    subject: 'all',
}, ]

export const _ = undefined